from django.shortcuts import render_to_response
def sometext(request):
    return render_to_response('myfirsttemplate.html',{'owner': 'James Payne',
                                           'books': 'American Gods',
                                           'author': 'Neil Gaimen'})

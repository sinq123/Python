#! /usr/bin/env jython

import sys

print('Python sys.path:')
print(sys.path)

print('Script arguments are:')
print(sys.argv)

import foo

foo.bar()


int encode(char *, char *);


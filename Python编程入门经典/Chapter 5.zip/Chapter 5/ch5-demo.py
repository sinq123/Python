# This a simple function that shows you how to store a value in #variables and then use the print() function to print them to the #screen.


#!/usr/bin/env python3.0

a = 10
b = 20

print("A added to B is %d" % (a + b))

from distutils.core import setup

setup(name='meal',
      version='1.0',
      py_modules=['meal'],
      )
